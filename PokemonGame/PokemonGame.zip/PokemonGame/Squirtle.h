#pragma once
#include "Pokemon.h"
class Squirtle :
    public Pokemon
{

public:
    Squirtle(int level);
    Squirtle(string in_name, int level);

    //methods

};

