#pragma once
#include "Pokemon.h"
class Pidgey :
    public Pokemon
{

public:
    Pidgey(int level);
    Pidgey(string in_name, int level);

    //methods
};

