#pragma once
#include "Pokemon.h"
class Spearow :
    public Pokemon
{
public:
    Spearow(int level);
    Spearow(string in_name, int level);
};

