#pragma once
#include "Pokemon.h"
class Caterpie :
    public Pokemon
{
public:
    Caterpie(int level);
    Caterpie(string in_name, int level);
};

