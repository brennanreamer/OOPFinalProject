#pragma once
#include "Pokemon.h"
class Charmander :
    public Pokemon
{
    
public:
    Charmander(int level);
    Charmander(string in_name, int level);

    //methods

};

