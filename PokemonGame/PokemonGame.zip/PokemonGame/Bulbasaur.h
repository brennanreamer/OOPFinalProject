#pragma once
#include "Pokemon.h"
class Bulbasaur :
    public Pokemon
{

public:
    Bulbasaur(int level);
    Bulbasaur(string in_name, int level);

    //methods

};

